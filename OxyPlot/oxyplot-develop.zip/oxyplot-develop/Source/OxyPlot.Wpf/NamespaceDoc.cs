﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="NamespaceDoc.cs" company="OxyPlot">
//   Copyright (c) 2014 OxyPlot contributors
// </copyright>
// <summary>
//   The OxyPlot.Wpf namespace contains WPF controls and PNG export functionality based on WPF.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace OxyPlot.Wpf
{
    /// <summary>
    /// The OxyPlot.Wpf namespace contains WPF controls and PNG export functionality based on WPF.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    internal class NamespaceDoc
    {
    }
}