﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AssemblyDescription.cs" company="OxyPlot">
//   Copyright (c) 2014 OxyPlot contributors
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

using System;
using System.Reflection;

[assembly: AssemblyTitle("OxyPlot for Silverlight")]
[assembly: AssemblyDescription("OxyPlot controls for Silverlight")]

[assembly: CLSCompliant(true)]