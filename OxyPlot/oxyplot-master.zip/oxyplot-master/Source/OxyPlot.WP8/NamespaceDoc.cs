﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="NamespaceDoc.cs" company="OxyPlot">
//   Copyright (c) 2014 OxyPlot contributors
// </copyright>
// <summary>
//   The OxyPlot.WP8 namespace contains controls for WP8.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace OxyPlot.WP8
{
    /// <summary>
    /// The OxyPlot.WP8 namespace contains controls for WP8.
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    internal class NamespaceDoc
    {
    }
}