//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Scatter3D.rc
//
#define IDD_SCATTER3D_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDC_GRAPH_TOPLEFT               1000
#define IDC_PROJ_TYPE                   1001
#define IDC_PROJ_TYPE2                  1002
#define IDC_SYMBOL_SIZE                 1003
#define IDC_MOUSE_ROTATE                1004
#define IDC_AUTO_X                      1005
#define IDC_AUTO_Y                      1006
#define IDC_AUTO_Z                      1007
#define IDC_MIN_X                       1008
#define IDC_MAX_X                       1009
#define IDC_MIN_Y                       1010
#define IDC_MIN_Z                       1011
#define IDC_MAX_Z                       1012
#define IDC_MAX_Y                       1013
#define IDC_LOAD                        1014
#define IDC_DAT_COUNT                   1015
#define IDC_COPY                        1016
#define IDC_PT_COL_TXT                  1017
#define IDC_MAKE_SEL                    1133
#define IDC_CANCEL_SEL                  1134
#define IDC_ZOOM_SEL                    1139
#define IDC_BACK_COLOUR                 1392
#define IDC_PT_COLOUR                   1393
#define IDC_SEL_FRAME                   1500

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
